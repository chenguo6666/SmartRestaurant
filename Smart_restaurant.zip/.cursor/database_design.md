# 智慧餐厅系统 - 数据库设计

## 数据库概述

智慧餐厅系统使用MySQL作为主数据库，Redis作为缓存数据库。数据库设计遵循关系型数据库设计原则，包含用户管理、菜品管理、订单管理、支付管理和促销管理等多个模块。

## 数据库表设计

### 1. 用户模块

#### 1.1 users 表（用户表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| openid | VARCHAR | 64 | NO | - | - | 微信用户唯一标识 |
| nickname | VARCHAR | 64 | YES | NULL | - | 用户昵称 |
| avatar_url | VARCHAR | 255 | YES | NULL | - | 用户头像URL |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |
| updated_at | DATETIME | - | YES | NULL | - | 更新时间 |

**索引：**
- PRIMARY KEY (`id`)
- UNIQUE KEY `idx_openid` (`openid`)

### 2. 菜品管理模块

#### 2.1 categories 表（菜品分类表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| name | VARCHAR | 64 | NO | - | - | 分类名称 |
| sort_order | INT | 11 | NO | 0 | - | 排序顺序 |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |
| updated_at | DATETIME | - | YES | NULL | - | 更新时间 |

**索引：**
- PRIMARY KEY (`id`)
- INDEX `idx_sort` (`sort_order`)

#### 2.2 dishes 表（菜品表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| category_id | INT | 11 | NO | - | - | 分类ID，外键关联categories.id |
| name | VARCHAR | 64 | NO | - | - | 菜品名称 |
| description | VARCHAR | 512 | YES | NULL | - | 菜品描述 |
| price | DECIMAL | (10,2) | NO | 0.00 | - | 价格 |
| image_url | VARCHAR | 255 | YES | NULL | - | 图片URL |
| stock | INT | 11 | NO | 0 | - | 库存量 |
| status | TINYINT | 1 | NO | 1 | - | 状态：1=上架，0=下架 |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |
| updated_at | DATETIME | - | YES | NULL | - | 更新时间 |

**索引：**
- PRIMARY KEY (`id`)
- INDEX `idx_category_id` (`category_id`)
- INDEX `idx_status` (`status`)

**外键约束：**
- FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE

### 3. 订单管理模块

#### 3.1 orders 表（订单表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| order_number | VARCHAR | 32 | NO | - | - | 订单号 |
| user_id | INT | 11 | NO | - | - | 用户ID，外键关联users.id |
| total_price | DECIMAL | (10,2) | NO | 0.00 | - | 订单总金额(原价) |
| final_price | DECIMAL | (10,2) | NO | 0.00 | - | 优惠后实付金额 |
| coupon_id | INT | 11 | YES | NULL | - | 优惠券ID，外键关联coupons.id |
| status | VARCHAR | 20 | NO | 'pending_payment' | - | 订单状态:待支付/已支付/制作中/已完成/已取消 |
| remark | VARCHAR | 255 | YES | NULL | - | 订单备注 |
| payment_method | VARCHAR | 20 | YES | NULL | - | 支付方式:微信支付等 |
| payment_time | DATETIME | - | YES | NULL | - | 支付时间 |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |
| updated_at | DATETIME | - | YES | NULL | - | 更新时间 |

**索引：**
- PRIMARY KEY (`id`)
- UNIQUE KEY `idx_order_number` (`order_number`)
- INDEX `idx_user_id` (`user_id`)
- INDEX `idx_status` (`status`)
- INDEX `idx_created_at` (`created_at`)

**外键约束：**
- FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
- FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`)

#### 3.2 order_items 表（订单明细表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| order_id | INT | 11 | NO | - | - | 订单ID，外键关联orders.id |
| dish_id | INT | 11 | NO | - | - | 菜品ID，外键关联dishes.id |
| dish_name | VARCHAR | 64 | NO | - | - | 下单时菜品名称(冗余) |
| price | DECIMAL | (10,2) | NO | 0.00 | - | 下单时菜品单价(冗余) |
| quantity | INT | 11 | NO | 1 | - | 数量 |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |

**索引：**
- PRIMARY KEY (`id`)
- INDEX `idx_order_id` (`order_id`)
- INDEX `idx_dish_id` (`dish_id`)

**外键约束：**
- FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
- FOREIGN KEY (`dish_id`) REFERENCES `dishes` (`id`)

### 4. 优惠券模块

#### 4.1 coupons 表（优惠券表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| name | VARCHAR | 64 | NO | - | - | 优惠券名称 |
| type | VARCHAR | 20 | NO | - | - | 类型:满减(amount_off)、折扣(discount) |
| value | DECIMAL | (10,2) | NO | 0.00 | - | 优惠值:满减金额或折扣率(0.1-1.0) |
| min_order_amount | DECIMAL | (10,2) | NO | 0.00 | - | 使用门槛(最低订单金额) |
| start_time | DATETIME | - | NO | - | - | 生效开始时间 |
| end_time | DATETIME | - | NO | - | - | 生效结束时间 |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |
| updated_at | DATETIME | - | YES | NULL | - | 更新时间 |

**索引：**
- PRIMARY KEY (`id`)
- INDEX `idx_type` (`type`)
- INDEX `idx_time_range` (`start_time`, `end_time`)

#### 4.2 user_coupons 表（用户优惠券关联表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| user_id | INT | 11 | NO | - | - | 用户ID，外键关联users.id |
| coupon_id | INT | 11 | NO | - | - | 优惠券ID，外键关联coupons.id |
| status | VARCHAR | 20 | NO | 'unused' | - | 状态:未使用(unused)/已使用(used)/已过期(expired) |
| used_time | DATETIME | - | YES | NULL | - | 使用时间 |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |

**索引：**
- PRIMARY KEY (`id`)
- INDEX `idx_user_id` (`user_id`)
- INDEX `idx_coupon_id` (`coupon_id`)
- INDEX `idx_status` (`status`)

**外键约束：**
- FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
- FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE

### 5. 餐厅信息模块

#### 5.1 restaurant_info 表（餐厅基本信息表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键(实际只有一条记录) |
| name | VARCHAR | 64 | NO | '智慧餐厅' | - | 餐厅名称 |
| logo | VARCHAR | 255 | YES | NULL | - | 餐厅logo URL |
| address | VARCHAR | 255 | YES | NULL | - | 餐厅地址 |
| phone | VARCHAR | 20 | YES | NULL | - | 联系电话 |
| business_hours | VARCHAR | 64 | YES | '09:00-22:00' | - | 营业时间 |
| announcement | VARCHAR | 512 | YES | NULL | - | 公告信息 |
| description | VARCHAR | 1024 | YES | NULL | - | 餐厅描述 |
| updated_at | DATETIME | - | YES | NULL | - | 更新时间 |

**索引：**
- PRIMARY KEY (`id`)

### 6. 管理员模块

#### 6.1 admins 表（管理员表）

| 字段名 | 类型 | 长度 | 是否为空 | 默认值 | 主键 | 说明 |
|-------|------|------|--------|-------|------|-----|
| id | INT | 11 | NO | - | PK | 自增主键 |
| username | VARCHAR | 32 | NO | - | - | 管理员用户名 |
| password | VARCHAR | 128 | NO | - | - | 加密后的密码 |
| name | VARCHAR | 64 | YES | NULL | - | 真实姓名 |
| phone | VARCHAR | 20 | YES | NULL | - | 联系电话 |
| last_login_time | DATETIME | - | YES | NULL | - | 最后登录时间 |
| created_at | DATETIME | - | NO | CURRENT_TIMESTAMP | - | 创建时间 |
| updated_at | DATETIME | - | YES | NULL | - | 更新时间 |

**索引：**
- PRIMARY KEY (`id`)
- UNIQUE KEY `idx_username` (`username`)

## 表关系图

```
users --< orders >-- dishes
   |       |
   |       |
   v       v
user_coupons  order_items
   ^
   |
   |
 coupons

categories --< dishes
```

## 数据库配置

### 字符集和排序规则

- 字符集: utf8mb4
- 排序规则: utf8mb4_unicode_ci

### 连接池配置

- 最大连接数: 100
- 最小连接数: 5
- 连接超时: 30s

### 索引策略

- 为所有外键建立索引
- 为常用查询条件建立索引
- 为排序字段建立索引
- 适当使用联合索引优化查询

## 数据迁移与版本管理

使用Django的迁移工具管理数据库版本：

1. 创建初始迁移
2. 为模型更改生成迁移脚本
3. 应用迁移更新数据库结构
4. 回滚迁移（必要时）

## 数据库备份策略

1. 每日全量备份
2. 实时binlog日志备份
3. 定期测试恢复过程

## Redis缓存设计

### 缓存内容

1. 菜品分类列表: `categories:all` (Hash)
2. 热门菜品列表: `dishes:hot` (Sorted Set)
3. 菜品详情: `dish:{dish_id}` (Hash)
4. 用户会话: `session:{token}` (Hash)
5. 订单状态: `order:status:{order_id}` (String)
6. 库存计数器: `stock:{dish_id}` (String)

### 缓存策略

1. 过期时间设置:
   - 菜品分类: 1天
   - 菜品详情: 1小时
   - 用户会话: 7天
   - 订单状态: 30分钟

2. 缓存更新策略:
   - 写操作同步更新缓存
   - 定时任务重建热门缓存

3. 缓存失效策略:
   - 时间过期自动失效
   - 数据更新时主动使相关缓存失效 