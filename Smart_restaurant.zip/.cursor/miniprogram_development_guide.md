# 微信小程序开发指南

## 一、小程序开发概述

智慧餐厅系统包含两个微信小程序：用户端(MP1)和管理端(MP2)。两个小程序共享相同的后端API，但功能和界面设计各不相同。

## 二、小程序开发环境搭建

### 2.1 开发工具安装

1. 下载并安装[微信开发者工具](https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html)最新版本
2. 注册微信小程序账号（分别注册用户端和管理端账号）
3. 在微信公众平台获取AppID

### 2.2 项目结构

用户端(MP1)和管理端(MP2)的目录结构类似：

```
frontend/user-mp/ 或 frontend/admin-mp/
├── pages/             # 页面目录
│   ├── index/         # 首页/菜单页
│   ├── cart/          # 购物车页
│   ├── my/            # 个人中心页
│   ├── order/         # 订单相关页面
│   └── ...
├── components/        # 自定义组件
│   ├── dish-item/     # 菜品项组件
│   ├── cart-item/     # 购物车项组件
│   └── ...
├── images/            # 图片资源
├── utils/             # 工具函数
│   ├── request.js     # 网络请求封装
│   ├── auth.js        # 认证工具
│   └── ...
├── styles/            # 公共样式
│   ├── common.wxss    # 通用样式
│   └── ...
├── app.js             # 小程序逻辑
├── app.json           # 小程序配置
└── app.wxss           # 小程序公共样式
```

## 三、小程序配置

### 3.1 全局配置 (app.json)

```json
{
  "pages": [
    "pages/index/index",
    "pages/cart/cart",
    "pages/my/my",
    "pages/order-list/order-list",
    "pages/order-detail/order-detail",
    "pages/dish-detail/dish-detail"
  ],
  "window": {
    "backgroundTextStyle": "light",
    "navigationBarBackgroundColor": "#FF5722",
    "navigationBarTitleText": "智慧餐厅",
    "navigationBarTextStyle": "white"
  },
  "tabBar": {
    "color": "#999999",
    "selectedColor": "#FF5722",
    "backgroundColor": "#ffffff",
    "borderStyle": "black",
    "list": [
      {
        "pagePath": "pages/index/index",
        "text": "菜单",
        "iconPath": "images/tabbar/menu.png",
        "selectedIconPath": "images/tabbar/menu-active.png"
      },
      {
        "pagePath": "pages/cart/cart",
        "text": "购物车",
        "iconPath": "images/tabbar/cart.png",
        "selectedIconPath": "images/tabbar/cart-active.png"
      },
      {
        "pagePath": "pages/my/my",
        "text": "我的",
        "iconPath": "images/tabbar/user.png",
        "selectedIconPath": "images/tabbar/user-active.png"
      }
    ]
  },
  "style": "v2",
  "sitemapLocation": "sitemap.json"
}
```

### 3.2 页面配置 (页面.json)

每个页面都可以有独立的配置，例如：

```json
{
  "navigationBarTitleText": "购物车",
  "enablePullDownRefresh": true,
  "usingComponents": {
    "cart-item": "/components/cart-item/cart-item"
  }
}
```

## 四、网络请求封装

### 4.1 request.js

```javascript
// utils/request.js
const BASE_URL = 'https://api.example.com/api/v1';

/**
 * 网络请求封装
 * @param {Object} options - 请求选项
 * @param {string} options.url - 请求地址（不含基础URL）
 * @param {string} options.method - 请求方法
 * @param {Object} options.data - 请求数据
 * @param {boolean} options.auth - 是否需要认证
 * @return {Promise} 请求Promise对象
 */
const request = (options) => {
  return new Promise((resolve, reject) => {
    const token = wx.getStorageSync('token');
    
    // 构造请求头
    const header = {
      'Content-Type': 'application/json'
    };
    
    // 如果需要认证且有token
    if (options.auth !== false && token) {
      header.Authorization = `Bearer ${token}`;
    }
    
    wx.request({
      url: BASE_URL + options.url,
      method: options.method || 'GET',
      data: options.data,
      header: header,
      success: (res) => {
        // 请求成功
        if (res.statusCode === 200) {
          // API返回成功码
          if (res.data.code === 0) {
            resolve(res.data.data);
          } else {
            // API返回错误码
            if (res.data.code === 2000) {
              // 未登录，跳转到登录流程
              handleAuthError();
              reject({ message: '请先登录', code: res.data.code });
            } else {
              // 其他业务错误
              wx.showToast({
                title: res.data.msg || '操作失败',
                icon: 'none'
              });
              reject({ message: res.data.msg, code: res.data.code });
            }
          }
        } else {
          // HTTP请求失败
          wx.showToast({
            title: `网络错误 (${res.statusCode})`,
            icon: 'none'
          });
          reject({ message: '网络错误', statusCode: res.statusCode });
        }
      },
      fail: (err) => {
        wx.showToast({
          title: '网络请求失败',
          icon: 'none'
        });
        reject({ message: '网络请求失败', error: err });
      }
    });
  });
};

// 处理认证错误
const handleAuthError = () => {
  wx.removeStorageSync('token');
  wx.removeStorageSync('userInfo');
  
  // 跳转到个人中心引导登录
  wx.switchTab({
    url: '/pages/my/my'
  });
};

// 封装各种HTTP方法
const http = {
  get: (url, data, options = {}) => {
    return request({
      url,
      method: 'GET',
      data,
      ...options
    });
  },
  
  post: (url, data, options = {}) => {
    return request({
      url,
      method: 'POST',
      data,
      ...options
    });
  },
  
  put: (url, data, options = {}) => {
    return request({
      url,
      method: 'PUT',
      data,
      ...options
    });
  },
  
  delete: (url, data, options = {}) => {
    return request({
      url,
      method: 'DELETE',
      data,
      ...options
    });
  }
};

export default http;
```

## 五、用户认证 (auth.js)

```javascript
// utils/auth.js
import http from './request';

/**
 * 微信登录
 * @return {Promise} 登录结果Promise
 */
const login = () => {
  return new Promise((resolve, reject) => {
    // 微信登录，获取code
    wx.login({
      success: res => {
        if (res.code) {
          // 发送code到后端换取token
          http.post('/auth/wxlogin', {
            code: res.code
          }, { auth: false }).then(data => {
            // 保存token和用户信息
            wx.setStorageSync('token', data.token);
            wx.setStorageSync('userInfo', data.user);
            resolve(data);
          }).catch(err => {
            reject(err);
          });
        } else {
          wx.showToast({
            title: '微信登录失败',
            icon: 'none'
          });
          reject({ message: '微信登录失败' });
        }
      },
      fail: err => {
        wx.showToast({
          title: '微信登录失败',
          icon: 'none'
        });
        reject({ message: '微信登录失败', error: err });
      }
    });
  });
};

/**
 * 检查是否已登录
 * @return {boolean} 是否已登录
 */
const isLoggedIn = () => {
  return !!wx.getStorageSync('token');
};

/**
 * 获取当前用户信息
 * @return {Object|null} 用户信息
 */
const getUserInfo = () => {
  return wx.getStorageSync('userInfo') || null;
};

/**
 * 登出
 */
const logout = () => {
  // 调用登出API
  http.post('/auth/logout').then(() => {
    wx.removeStorageSync('token');
    wx.removeStorageSync('userInfo');
    // 重定向到个人中心页
    wx.switchTab({
      url: '/pages/my/my'
    });
  }).catch(() => {
    // 即使API调用失败，也清除本地登录状态
    wx.removeStorageSync('token');
    wx.removeStorageSync('userInfo');
    wx.switchTab({
      url: '/pages/my/my'
    });
  });
};

export default {
  login,
  isLoggedIn,
  getUserInfo,
  logout
};
```

## 六、购物车功能 (cart.js)

```javascript
// utils/cart.js

/**
 * 购物车管理工具
 * 购物车数据使用本地存储实现
 */

const CART_KEY = 'cart_items';

/**
 * 获取购物车所有商品
 * @return {Array} 购物车商品列表
 */
const getCartItems = () => {
  return wx.getStorageSync(CART_KEY) || [];
};

/**
 * 添加商品到购物车
 * @param {Object} dish 菜品对象
 * @param {number} quantity 数量
 * @return {Array} 更新后的购物车
 */
const addToCart = (dish, quantity = 1) => {
  const cartItems = getCartItems();
  const index = cartItems.findIndex(item => item.id === dish.id);
  
  if (index > -1) {
    // 商品已在购物车中，增加数量
    cartItems[index].quantity += quantity;
  } else {
    // 商品不在购物车中，添加新商品
    cartItems.push({
      id: dish.id,
      name: dish.name,
      price: dish.price,
      image_url: dish.image_url,
      quantity: quantity
    });
  }
  
  // 保存更新后的购物车
  wx.setStorageSync(CART_KEY, cartItems);
  
  // 更新购物车图标
  updateTabBarBadge();
  
  return cartItems;
};

/**
 * 从购物车移除商品
 * @param {number} dishId 菜品ID
 * @return {Array} 更新后的购物车
 */
const removeFromCart = (dishId) => {
  let cartItems = getCartItems();
  cartItems = cartItems.filter(item => item.id !== dishId);
  
  // 保存更新后的购物车
  wx.setStorageSync(CART_KEY, cartItems);
  
  // 更新购物车图标
  updateTabBarBadge();
  
  return cartItems;
};

/**
 * 更新购物车中商品数量
 * @param {number} dishId 菜品ID
 * @param {number} quantity 新数量
 * @return {Array} 更新后的购物车
 */
const updateQuantity = (dishId, quantity) => {
  const cartItems = getCartItems();
  const index = cartItems.findIndex(item => item.id === dishId);
  
  if (index > -1) {
    if (quantity > 0) {
      // 更新数量
      cartItems[index].quantity = quantity;
    } else {
      // 数量为0，从购物车移除
      cartItems.splice(index, 1);
    }
  }
  
  // 保存更新后的购物车
  wx.setStorageSync(CART_KEY, cartItems);
  
  // 更新购物车图标
  updateTabBarBadge();
  
  return cartItems;
};

/**
 * 清空购物车
 * @return {Array} 空购物车
 */
const clearCart = () => {
  wx.setStorageSync(CART_KEY, []);
  
  // 更新购物车图标
  updateTabBarBadge();
  
  return [];
};

/**
 * 获取购物车中商品总数
 * @return {number} 商品总数
 */
const getCartCount = () => {
  const cartItems = getCartItems();
  return cartItems.reduce((total, item) => total + item.quantity, 0);
};

/**
 * 获取购物车总金额
 * @return {number} 总金额
 */
const getCartTotal = () => {
  const cartItems = getCartItems();
  return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
};

/**
 * 更新购物车Tab徽标
 */
const updateTabBarBadge = () => {
  const count = getCartCount();
  
  if (count > 0) {
    wx.setTabBarBadge({
      index: 1, // 购物车Tab的索引
      text: count.toString()
    }).catch(() => {
      // 忽略可能的错误，例如当前页面不是TabBar页面
    });
  } else {
    wx.removeTabBarBadge({
      index: 1
    }).catch(() => {
      // 忽略可能的错误
    });
  }
};

export default {
  getCartItems,
  addToCart,
  removeFromCart,
  updateQuantity,
  clearCart,
  getCartCount,
  getCartTotal,
  updateTabBarBadge
};
```

## 七、页面开发示例

### 7.1 菜单页面 (index.js)

```javascript
// pages/index/index.js
import http from '../../utils/request';
import cart from '../../utils/cart';

Page({
  data: {
    categories: [],           // 菜品分类列表
    dishes: [],               // 当前分类的菜品列表
    currentCategory: null,    // 当前选中分类
    cartItems: [],            // 购物车内商品
    searchValue: '',          // 搜索关键字
    loading: false            // 加载状态
  },
  
  onLoad: function() {
    // 加载菜品分类
    this.loadCategories();
    
    // 从本地存储获取购物车商品
    this.setData({
      cartItems: cart.getCartItems()
    });
  },
  
  onShow: function() {
    // 刷新购物车数据
    this.setData({
      cartItems: cart.getCartItems()
    });
    
    // 更新TabBar徽标
    cart.updateTabBarBadge();
  },
  
  // 加载菜品分类
  loadCategories: function() {
    this.setData({ loading: true });
    
    http.get('/categories').then(res => {
      if (res.categories && res.categories.length > 0) {
        this.setData({
          categories: res.categories,
          currentCategory: res.categories[0].id
        });
        
        // 加载第一个分类的菜品
        this.loadDishes(res.categories[0].id);
      }
    }).catch(() => {
      this.setData({ loading: false });
    });
  },
  
  // 加载指定分类下的菜品
  loadDishes: function(categoryId) {
    this.setData({ loading: true });
    
    http.get('/dishes', { category_id: categoryId }).then(res => {
      this.setData({
        dishes: res.dishes || [],
        loading: false
      });
    }).catch(() => {
      this.setData({ loading: false });
    });
  },
  
  // 切换分类
  handleCategoryTap: function(e) {
    const categoryId = e.currentTarget.dataset.id;
    this.setData({ currentCategory: categoryId });
    this.loadDishes(categoryId);
  },
  
  // 搜索菜品
  handleSearch: function(e) {
    const value = e.detail.value;
    this.setData({ searchValue: value });
    
    if (value) {
      this.setData({ loading: true });
      http.get('/dishes', { keyword: value }).then(res => {
        this.setData({
          dishes: res.dishes || [],
          loading: false
        });
      }).catch(() => {
        this.setData({ loading: false });
      });
    } else {
      // 搜索框为空，加载当前分类菜品
      this.loadDishes(this.data.currentCategory);
    }
  },
  
  // 添加菜品到购物车
  handleAddToCart: function(e) {
    const dishId = e.currentTarget.dataset.id;
    const dish = this.data.dishes.find(item => item.id === dishId);
    
    if (dish) {
      // 添加到购物车
      cart.addToCart(dish, 1);
      
      // 更新页面数据
      this.setData({
        cartItems: cart.getCartItems()
      });
      
      wx.showToast({
        title: '已加入购物车',
        icon: 'success',
        duration: 1000
      });
    }
  },
  
  // 增加购物车商品数量
  handleIncrease: function(e) {
    const dishId = e.currentTarget.dataset.id;
    const dish = this.data.dishes.find(item => item.id === dishId);
    const cartItem = this.data.cartItems.find(item => item.id === dishId);
    
    if (dish) {
      const quantity = (cartItem ? cartItem.quantity : 0) + 1;
      cart.updateQuantity(dishId, quantity);
      
      this.setData({
        cartItems: cart.getCartItems()
      });
    }
  },
  
  // 减少购物车商品数量
  handleDecrease: function(e) {
    const dishId = e.currentTarget.dataset.id;
    const cartItem = this.data.cartItems.find(item => item.id === dishId);
    
    if (cartItem && cartItem.quantity > 0) {
      cart.updateQuantity(dishId, cartItem.quantity - 1);
      
      this.setData({
        cartItems: cart.getCartItems()
      });
    }
  },
  
  // 跳转到菜品详情
  navigateToDishDetail: function(e) {
    const dishId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/dish-detail/dish-detail?id=${dishId}`
    });
  }
});
```

### 7.2 菜单页面WXML (index.wxml)

```html
<!-- pages/index/index.wxml -->
<view class="menu-container">
  <!-- 搜索框 -->
  <view class="search-box">
    <input 
      class="search-input"
      placeholder="搜索菜品"
      bindinput="handleSearch"
      value="{{searchValue}}"
    />
  </view>
  
  <view class="menu-content">
    <!-- 左侧分类列表 -->
    <scroll-view scroll-y class="category-list">
      <view 
        wx:for="{{categories}}" 
        wx:key="id" 
        class="category-item {{currentCategory === item.id ? 'active' : ''}}"
        data-id="{{item.id}}"
        bindtap="handleCategoryTap"
      >
        {{item.name}}
      </view>
    </scroll-view>
    
    <!-- 右侧菜品列表 -->
    <scroll-view scroll-y class="dish-list">
      <view wx:if="{{loading}}" class="loading">加载中...</view>
      
      <view wx:elif="{{dishes.length === 0}}" class="empty-tips">
        没有找到相关菜品
      </view>
      
      <view wx:else class="dish-list-content">
        <view 
          wx:for="{{dishes}}" 
          wx:key="id" 
          class="dish-item"
          data-id="{{item.id}}"
          bindtap="navigateToDishDetail"
        >
          <image class="dish-image" src="{{item.image_url}}" mode="aspectFill" />
          <view class="dish-info">
            <view class="dish-name">{{item.name}}</view>
            <view class="dish-desc">{{item.description}}</view>
            <view class="dish-price">¥{{item.price}}</view>
          </view>
          
          <!-- 添加购物车 -->
          <view class="dish-actions" catchtap="stopPropagation">
            <view wx:if="{{!cartItems.find(x => x.id === item.id)}}" class="add-btn" catchtap="handleAddToCart" data-id="{{item.id}}">+</view>
            <view wx:else class="counter">
              <view class="decrease" catchtap="handleDecrease" data-id="{{item.id}}">-</view>
              <view class="count">{{cartItems.find(x => x.id === item.id).quantity}}</view>
              <view class="increase" catchtap="handleIncrease" data-id="{{item.id}}">+</view>
            </view>
          </view>
        </view>
      </view>
    </scroll-view>
  </view>
</view>
```

## 八、小程序开发注意事项

1. **性能优化**
   - 避免频繁setData更新大量数据
   - 合理使用懒加载和分页加载
   - 优化图片大小和格式

2. **用户体验**
   - 添加适当的加载提示
   - 对网络请求失败提供友好提示
   - 优化小程序冷启动体验

3. **本地存储管理**
   - 合理使用Storage存储用户数据
   - 避免滥用Storage存储大量数据
   - 定期清理过期数据

4. **兼容性考虑**
   - 适配不同屏幕尺寸
   - 兼容不同微信版本
   - 测试在不同机型上的显示效果

5. **安全性**
   - 敏感信息不要存储在前端
   - 做好请求参数验证
   - 保持token的安全管理

6. **小程序分包**
   - 合理规划分包结构
   - 优化首次启动时间
   - 主包保持精简

7. **组件化开发**
   - 抽象通用组件
   - 保持组件的可复用性
   - 减少代码冗余

## 九、小程序发布流程

1. **体验版测试**
   - 在开发者工具中上传代码
   - 设置体验版本
   - 进行功能测试和Bug修复

2. **提交审核**
   - 填写版本信息
   - 提交小程序代码审核
   - 等待审核结果

3. **发布上线**
   - 审核通过后发布小程序
   - 设置线上版本号
   - 监控小程序运行状况 