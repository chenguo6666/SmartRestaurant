# 智慧餐厅系统 - API文档

## API概览

智慧餐厅系统的后端提供完整的RESTful API，供微信小程序前端调用。所有API遵循相同的响应格式，使用JWT进行身份验证。

### 通用响应格式

```json
{
  "code": 0,       // 状态码，0表示成功，非0表示错误
  "msg": "success", // 状态信息
  "data": {}       // 响应数据
}
```

### API基础路径

所有API路径均以 `/api/v1/` 为前缀，例如：`https://api.smartrestaurant.com/api/v1/dishes`

### 身份验证

除了登录API，其他所有API请求需要在HTTP请求的头部包含JWT令牌：

```
Authorization: Bearer {token}
```

## API详细说明

### 1. 用户模块

#### 1.1 微信登录

- **URL**: `/api/v1/auth/wxlogin`
- **方法**: POST
- **描述**: 使用微信授权登录，获取JWT令牌
- **参数**:
  ```json
  {
    "code": "xxx" // 微信登录code
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "token": "xxx.yyy.zzz", // JWT令牌
      "user": {
        "id": 1,
        "nickname": "用户昵称",
        "avatar_url": "头像URL",
        "is_new": false // 是否新用户
      }
    }
  }
  ```

#### 1.2 获取用户信息

- **URL**: `/api/v1/users/me`
- **方法**: GET
- **描述**: 获取当前登录用户信息
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 1,
      "nickname": "用户昵称",
      "avatar_url": "头像URL",
      "created_at": "2023-01-01T12:00:00Z"
    }
  }
  ```

#### 1.3 退出登录

- **URL**: `/api/v1/auth/logout`
- **方法**: POST
- **描述**: 用户退出登录，使当前JWT令牌失效
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {}
  }
  ```

### 2. 菜品分类模块

#### 2.1 获取菜品分类列表

- **URL**: `/api/v1/categories`
- **方法**: GET
- **描述**: 获取所有菜品分类
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "categories": [
        {
          "id": 1,
          "name": "热菜",
          "sort_order": 1
        },
        {
          "id": 2,
          "name": "凉菜",
          "sort_order": 2
        }
      ]
    }
  }
  ```

#### 2.2 添加菜品分类

- **URL**: `/api/v1/categories`
- **方法**: POST
- **描述**: 管理员添加新的菜品分类
- **权限**: 管理员
- **参数**:
  ```json
  {
    "name": "甜品",
    "sort_order": 3
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 3,
      "name": "甜品",
      "sort_order": 3,
      "created_at": "2023-01-01T12:00:00Z"
    }
  }
  ```

#### 2.3 修改菜品分类

- **URL**: `/api/v1/categories/{category_id}`
- **方法**: PUT
- **描述**: 管理员修改菜品分类信息
- **权限**: 管理员
- **参数**:
  ```json
  {
    "name": "精品甜品",
    "sort_order": 3
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 3,
      "name": "精品甜品",
      "sort_order": 3,
      "updated_at": "2023-01-02T12:00:00Z"
    }
  }
  ```

#### 2.4 删除菜品分类

- **URL**: `/api/v1/categories/{category_id}`
- **方法**: DELETE
- **描述**: 管理员删除菜品分类
- **权限**: 管理员
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {}
  }
  ```

### 3. 菜品模块

#### 3.1 获取菜品列表

- **URL**: `/api/v1/dishes`
- **方法**: GET
- **描述**: 获取菜品列表，可按分类筛选
- **参数**:
  - `category_id`: 分类ID（可选）
  - `keyword`: 搜索关键字（可选）
  - `page`: 页码，默认1
  - `page_size`: 每页数量，默认20
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "total": 100,
      "page": 1,
      "page_size": 20,
      "dishes": [
        {
          "id": 1,
          "category_id": 1,
          "category_name": "热菜",
          "name": "宫保鸡丁",
          "description": "经典川菜",
          "price": 38.00,
          "image_url": "https://example.com/image1.jpg",
          "stock": 100,
          "status": 1 // 1表示上架，0表示下架
        }
      ]
    }
  }
  ```

#### 3.2 获取菜品详情

- **URL**: `/api/v1/dishes/{dish_id}`
- **方法**: GET
- **描述**: 获取指定菜品的详细信息
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 1,
      "category_id": 1,
      "category_name": "热菜",
      "name": "宫保鸡丁",
      "description": "经典川菜，以鸡丁、花生、辣椒为主要材料...",
      "price": 38.00,
      "image_url": "https://example.com/image1.jpg",
      "stock": 100,
      "status": 1,
      "created_at": "2023-01-01T12:00:00Z",
      "updated_at": "2023-01-01T12:00:00Z"
    }
  }
  ```

#### 3.3 添加菜品

- **URL**: `/api/v1/dishes`
- **方法**: POST
- **描述**: 管理员添加新菜品
- **权限**: 管理员
- **参数**:
  ```json
  {
    "category_id": 1,
    "name": "麻婆豆腐",
    "description": "四川传统名菜，以豆腐、牛肉末、辣椒为主料",
    "price": 28.00,
    "image_url": "https://example.com/mapo_tofu.jpg",
    "stock": 50,
    "status": 1
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 2,
      "category_id": 1,
      "name": "麻婆豆腐",
      "description": "四川传统名菜，以豆腐、牛肉末、辣椒为主料",
      "price": 28.00,
      "image_url": "https://example.com/mapo_tofu.jpg",
      "stock": 50,
      "status": 1,
      "created_at": "2023-01-02T12:00:00Z"
    }
  }
  ```

#### 3.4 修改菜品

- **URL**: `/api/v1/dishes/{dish_id}`
- **方法**: PUT
- **描述**: 管理员修改菜品信息
- **权限**: 管理员
- **参数**:
  ```json
  {
    "category_id": 1,
    "name": "特色麻婆豆腐",
    "description": "本店特色麻婆豆腐，选用上等豆腐",
    "price": 32.00,
    "image_url": "https://example.com/special_mapo_tofu.jpg",
    "stock": 60,
    "status": 1
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 2,
      "category_id": 1,
      "name": "特色麻婆豆腐",
      "description": "本店特色麻婆豆腐，选用上等豆腐",
      "price": 32.00,
      "image_url": "https://example.com/special_mapo_tofu.jpg",
      "stock": 60,
      "status": 1,
      "updated_at": "2023-01-03T12:00:00Z"
    }
  }
  ```

#### 3.5 删除菜品

- **URL**: `/api/v1/dishes/{dish_id}`
- **方法**: DELETE
- **描述**: 管理员删除菜品
- **权限**: 管理员
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {}
  }
  ```

#### 3.6 修改菜品状态

- **URL**: `/api/v1/dishes/{dish_id}/status`
- **方法**: PUT
- **描述**: 管理员修改菜品上/下架状态
- **权限**: 管理员
- **参数**:
  ```json
  {
    "status": 0  // 0表示下架，1表示上架
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 2,
      "status": 0,
      "updated_at": "2023-01-04T12:00:00Z"
    }
  }
  ```

### 4. 订单模块

#### 4.1 创建订单

- **URL**: `/api/v1/orders`
- **方法**: POST
- **描述**: 用户提交订单
- **参数**:
  ```json
  {
    "items": [
      {
        "dish_id": 1,
        "quantity": 2
      },
      {
        "dish_id": 2,
        "quantity": 1
      }
    ],
    "coupon_id": 1,  // 优惠券ID，可选
    "remark": "不要辣" // 备注，可选
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "order_id": 1,
      "order_number": "202301010001",
      "total_price": 104.00, // 原价总金额
      "final_price": 94.00,  // 优惠后金额
      "status": "pending_payment", // 待支付
      "created_at": "2023-01-05T12:00:00Z",
      "payment": {
        "payment_params": {} // 支付参数，用于小程序调起支付
      }
    }
  }
  ```

#### 4.2 获取订单列表

- **URL**: `/api/v1/orders`
- **方法**: GET
- **描述**: 用户获取自己的订单列表
- **参数**:
  - `status`: 订单状态（可选）
  - `page`: 页码，默认1
  - `page_size`: 每页数量，默认20
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "total": 10,
      "page": 1,
      "page_size": 20,
      "orders": [
        {
          "id": 1,
          "order_number": "202301010001",
          "total_price": 104.00,
          "final_price": 94.00,
          "status": "paid", // 已支付
          "created_at": "2023-01-05T12:00:00Z"
        }
      ]
    }
  }
  ```

#### 4.3 获取订单详情

- **URL**: `/api/v1/orders/{order_id}`
- **方法**: GET
- **描述**: 获取指定订单的详细信息
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 1,
      "order_number": "202301010001",
      "total_price": 104.00,
      "final_price": 94.00,
      "status": "paid",
      "remark": "不要辣",
      "created_at": "2023-01-05T12:00:00Z",
      "updated_at": "2023-01-05T12:10:00Z",
      "items": [
        {
          "dish_id": 1,
          "dish_name": "宫保鸡丁",
          "price": 38.00,
          "quantity": 2,
          "image_url": "https://example.com/image1.jpg"
        },
        {
          "dish_id": 2,
          "dish_name": "麻婆豆腐",
          "price": 28.00,
          "quantity": 1,
          "image_url": "https://example.com/mapo_tofu.jpg"
        }
      ],
      "coupon": {
        "id": 1,
        "name": "满100减10",
        "type": "amount_off",
        "value": 10.00
      }
    }
  }
  ```

#### 4.4 取消订单

- **URL**: `/api/v1/orders/{order_id}/cancel`
- **方法**: POST
- **描述**: 用户取消未支付订单
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 1,
      "status": "canceled",
      "updated_at": "2023-01-05T12:30:00Z"
    }
  }
  ```

#### 4.5 管理员获取所有订单

- **URL**: `/api/v1/admin/orders`
- **方法**: GET
- **描述**: 管理员获取所有订单列表
- **权限**: 管理员
- **参数**:
  - `status`: 订单状态（可选）
  - `date`: 日期，格式YYYY-MM-DD（可选）
  - `page`: 页码，默认1
  - `page_size`: 每页数量，默认20
- **响应**: 与4.2类似，但包含用户信息

#### 4.6 管理员更新订单状态

- **URL**: `/api/v1/admin/orders/{order_id}/status`
- **方法**: PUT
- **描述**: 管理员更新订单状态
- **权限**: 管理员
- **参数**:
  ```json
  {
    "status": "processing" // 可选值: paid, processing, completed, canceled
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 1,
      "status": "processing",
      "updated_at": "2023-01-05T13:00:00Z"
    }
  }
  ```

### 5. 支付模块

#### 5.1 支付回调

- **URL**: `/api/v1/payments/wxpay/notify`
- **方法**: POST
- **描述**: 微信支付结果回调接口
- **参数**: 微信支付回调数据（XML格式）
- **响应**: 固定XML格式，表示接收结果

### 6. 优惠券模块

#### 6.1 获取优惠券列表

- **URL**: `/api/v1/coupons`
- **方法**: GET
- **描述**: 获取当前用户可用的优惠券列表
- **参数**:
  - `status`: 优惠券状态（可选，默认为未使用）
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "coupons": [
        {
          "id": 1,
          "name": "满100减10",
          "type": "amount_off",
          "value": 10.00,
          "min_order_amount": 100.00,
          "status": "unused",
          "start_time": "2023-01-01T00:00:00Z",
          "end_time": "2023-02-01T23:59:59Z"
        }
      ]
    }
  }
  ```

#### 6.2 管理员创建优惠券

- **URL**: `/api/v1/admin/coupons`
- **方法**: POST
- **描述**: 管理员创建优惠券
- **权限**: 管理员
- **参数**:
  ```json
  {
    "name": "满200减30",
    "type": "amount_off", // 或 "discount"
    "value": 30.00, // 满减金额或折扣率（0.1-1.0）
    "min_order_amount": 200.00,
    "start_time": "2023-02-01T00:00:00Z",
    "end_time": "2023-03-01T23:59:59Z"
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "id": 2,
      "name": "满200减30",
      "type": "amount_off",
      "value": 30.00,
      "min_order_amount": 200.00,
      "start_time": "2023-02-01T00:00:00Z",
      "end_time": "2023-03-01T23:59:59Z",
      "created_at": "2023-01-10T12:00:00Z"
    }
  }
  ```

### 7. 餐厅信息模块

#### 7.1 获取餐厅信息

- **URL**: `/api/v1/restaurant/info`
- **方法**: GET
- **描述**: 获取餐厅基本信息
- **参数**: 无
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "name": "智慧餐厅",
      "logo": "https://example.com/logo.jpg",
      "address": "北京市海淀区中关村大街1号",
      "phone": "010-12345678",
      "business_hours": "09:00-22:00",
      "announcement": "欢迎光临本店",
      "description": "本店主营川菜，口味正宗"
    }
  }
  ```

#### 7.2 修改餐厅信息

- **URL**: `/api/v1/admin/restaurant/info`
- **方法**: PUT
- **描述**: 管理员修改餐厅信息
- **权限**: 管理员
- **参数**:
  ```json
  {
    "name": "智慧餐厅（中关村店）",
    "logo": "https://example.com/new_logo.jpg",
    "address": "北京市海淀区中关村大街1号",
    "phone": "010-12345678",
    "business_hours": "10:00-22:00",
    "announcement": "本周推出新品特惠活动",
    "description": "本店主营川菜，口味正宗，环境舒适"
  }
  ```
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "name": "智慧餐厅（中关村店）",
      "logo": "https://example.com/new_logo.jpg",
      "address": "北京市海淀区中关村大街1号",
      "phone": "010-12345678",
      "business_hours": "10:00-22:00",
      "announcement": "本周推出新品特惠活动",
      "description": "本店主营川菜，口味正宗，环境舒适",
      "updated_at": "2023-01-15T12:00:00Z"
    }
  }
  ```

### 8. 统计分析模块

#### 8.1 获取销售统计

- **URL**: `/api/v1/admin/statistics/sales`
- **方法**: GET
- **描述**: 管理员获取销售统计数据
- **权限**: 管理员
- **参数**:
  - `period`: 统计周期（day, week, month），默认day
  - `date`: 日期，格式YYYY-MM-DD，默认今天
- **响应**:
  ```json
  {
    "code": 0,
    "msg": "success",
    "data": {
      "period": "day",
      "date": "2023-01-20",
      "total_orders": 58,
      "total_sales": 4267.00,
      "hourly_data": [
        {
          "hour": "10",
          "orders": 5,
          "sales": 386.00
        },
        {
          "hour": "11",
          "orders": 12,
          "sales": 978.00
        }
        // ... 其他小时统计 ...
      ]
    }
  }
  ```

## 错误码说明

- 0: 成功
- 1000: 系统错误
- 1001: 参数错误
- 1002: 资源不存在
- 2000: 用户未登录
- 2001: 登录失败
- 2002: 权限不足
- 3000: 菜品不存在
- 3001: 菜品已下架
- 3002: 库存不足
- 4000: 订单创建失败
- 4001: 订单不存在
- 4002: 订单状态错误
- 5000: 支付失败
- 6000: 优惠券不存在
- 6001: 优惠券已过期
- 6002: 优惠券不可用 